#include <windows.h>
#include "gui.h"

MPEG2PLAY ICON GRAYLEO.ICO

//////////////////////////////////////////////////////////////////////////////
//
// Menu
//

MPEG2PLAY MENU DISCARDABLE
BEGIN
    POPUP "&File"
    BEGIN
        MENUITEM "&Open...",                    IDM_OPEN
        MENUITEM SEPARATOR
        MENUITEM "E&xit",                       IDM_EXIT
    END
    POPUP "&Control"
    BEGIN
        MENUITEM "&Play\tCtrl+P",               IDM_PLAY, GRAYED
        MENUITEM "&Stop\tCtrl+S",               IDM_STOP, GRAYED
    END
    POPUP "&Dither"
    BEGIN
#ifdef DISPLAY
        MENUITEM "To &Screen - 8 bits dithered",IDM_DISPLAY8
        MENUITEM "To &Screen - 24 bits",        IDM_DISPLAY24
#endif
        MENUITEM "To &Combined YUV File",       IDM_YUV_FILE
        MENUITEM "To Separate &YUV File",       IDM_Y_U_V_FILE
        MENUITEM "To &TGA File",                IDM_TGA_FILE
    END
    POPUP "&Help"
    BEGIN
        MENUITEM "&About...",                   IDM_ABOUT
    END
END


//////////////////////////////////////////////////////////////////////////////
//
// Accelerator
//

MPEG2PLAY ACCELERATORS MOVEABLE PURE
BEGIN
    "?",            IDM_ABOUT,              ASCII,  ALT
    "/",            IDM_ABOUT,              ASCII,  ALT
    "^P",           IDM_PLAY,               ASCII
    "^C",           IDM_PLAY_CONT,          ASCII
    "^S",           IDM_STOP,               ASCII
END


//////////////////////////////////////////////////////////////////////////////
//
// Dialog
//

ABOUTBOX DIALOG DISCARDABLE  25, 17, 171, 69
STYLE DS_MODALFRAME | WS_CAPTION | WS_SYSMENU
FONT 8, "System"
BEGIN
    DEFPUSHBUTTON   "OK",IDOK,68,50,32,14,WS_GROUP
    CONTROL         "MPEG Software Simulation Group",DLG_VERFIRST,"Static",
                    SS_LEFTNOWORDWRAP | WS_GROUP,30,2,141,8
    CONTROL         "Mpeg-2 Video Decoder",401,"Static",SS_LEFTNOWORDWRAP |
                    WS_GROUP,30,16,82,8
    LTEXT           "Ver. 1.1",402,121,16,33,8
    CONTROL         "",501,"Static",SS_BLACKRECT,2,44,167,1
    LTEXT           "MPEG-L@netcom.com",-1,31,33,78,8
END
